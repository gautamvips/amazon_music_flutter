import 'package:flutter/material.dart';
import 'package:music_app/navigation/alexa.dart';
import 'package:music_app/navigation/profile.dart';
import 'package:music_app/navigation/search.dart';
import 'package:music_app/screens/secondpage.dart';


class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = const [
    HomePage2(),
    search(),
    profile(),
    alexa(),
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: screens[currentIndexs],
        bottomNavigationBar: BottomNavigationBar(
          selectedLabelStyle: TextStyle(color: Colors.white),
            currentIndex: currentIndexs,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                currentIndexs = value;
              });
            },
            backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white.withOpacity(.60),
            selectedFontSize: 13,
            unselectedFontSize: 10,
            items: const [
              BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
              BottomNavigationBarItem(
                  label: "Search", icon: Icon(Icons.search)),
              BottomNavigationBarItem(
                  label: "Profile", icon: Icon(Icons.person)),
              BottomNavigationBarItem(
                  label: "Alexa", icon: Icon(Icons.voice_chat)),
            ]),
      ),
    );
  }
}
